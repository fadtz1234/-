var mySwiper = new Swiper ('.swiper-container', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项

    autoplay:true,
    //等同于以下设置
    autoplay: {
    delay: 3000,
    stopOnLastSlide: false,
    disableOnInteraction: true,
    },

  })     
// 点击图片跳转   
$("#go").click(function(){
      window.location.href="https://pro-pc.yhd.com/yhd/active/33KCN39KAit5hcQDiaoHaa8L39aX/index.html"
})
// 倒计时 
$(document).ready(function () {
  var oDate = new Date();
  var nowTime = oDate.getTime(); //现在的毫秒数
  oDate.setDate(oDate.getDate() + 1); // 设定截止时间为第二天
  var targetDate = new Date(oDate.toLocaleDateString());
  run(targetDate);
});

function run(enddate) {
  getDate(enddate);
  setInterval("getDate('" + enddate + "')", 500);
}

function getDate(enddate) {
  var oDate = new Date(); //获取日期对象

  var nowTime = oDate.getTime(); //现在的毫秒数
  var enddate = new Date(enddate);
  var targetTime = enddate.getTime(); // 截止时间的毫秒数
  var second = Math.floor((targetTime - nowTime) / 1000); //截止时间距离现在的秒数

  var day = Math.floor(second / 24 * 60 * 60); //整数部分代表的是天；一天有24*60*60=86400秒 ；
  second = second % 86400; //余数代表剩下的秒数；
  var hour = Math.floor(second / 3600); //整数部分代表小时；
  second %= 3600; //余数代表 剩下的秒数；
  var minute = Math.floor(second / 60);
  second %= 60;
  var spanH = $('.se-txt')[0];
  var spanM = $('.se-txt')[1];
  var spanS = $('.se-txt')[2];

  spanH.innerHTML = tow(hour);
  spanM.innerHTML = tow(minute);
  spanS.innerHTML = tow(second);
}

function tow(n) {
  return n >= 0 && n < 10 ? '0' + n : '' + n;
}

// 点击
// 绑定第一个div的点击事件
$("#tab-top").click(function (e) { 
  // 给你点击的div添加选中的class
  // 去除另外两个div的选中class
  
  $("#tab-top").addClass("tt");
  $("#tab-top2").removeClass("tt")
  $("#tab-top3").removeClass("tt")
  // attrs 是设置属性，通过设置属性更换图片
  $("#img").attr("src","./tuku/1.jpg")
});
$("#tab-top2").click(function (e) { 
  e.preventDefault();
  $("#tab-top2").addClass("tt");
  $("#tab-top").removeClass("tt")
  $("#tab-top3").removeClass("tt")
  $("#img").attr("src","./tuku/2.jpg")
});
$("#tab-top3").click(function (e) { 
  e.preventDefault();
  $("#tab-top3").addClass("tt");
  $("#tab-top2").removeClass("tt")
  $("#tab-top").removeClass("tt")
  $("#img").attr("src","./tuku/3.jpg")
});

$("#tab-top").mouseover(function (){
  $("#tab-top").addClass("tt");
});
$("#tab-top").mouseover(function (){
  $("#tab-top").removeClass("tt")
});
$("#tab-top2").mouseover(function (){
  $("#tab-top2").addClass("tt");
});
$("#tab-top2").mouseover(function (){
  $("#tab-top2").removeClass("tt")
});
