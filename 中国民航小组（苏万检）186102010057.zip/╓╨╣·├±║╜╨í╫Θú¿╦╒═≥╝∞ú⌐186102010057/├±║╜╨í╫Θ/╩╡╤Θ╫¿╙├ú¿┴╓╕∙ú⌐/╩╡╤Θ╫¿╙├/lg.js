var mySwiper2 = new Swiper ('#top2', {
    // direction: 'vertical', 
    // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    pagination: {
      el: '#top2-page',
      
    },
    effect : 'fade',
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '#top2-prev',
      prevEl: '#top2-next',
    },
    
    // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },


    autoplay: {
        delay: 5000,
        stopOnLastSlide: false,
        disableOnInteraction: true,
        },
    mousewheel: true,
    keyboard: {
            enabled: true,
            onlyInViewport: true,
          },
    
    
  }) 