// 这个是定义一个轮播对象var mySwiper = new Swiper (
var mySwiper = new Swiper ('#top', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    // pagination: {
    //   el: '#top-page',
    // },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '#top-prev',
      prevEl: '#top-next',
    },
    
    // // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },

    autoplay: {
      delay: 5000,
      stopOnLastSlide: false,
      disableOnInteraction: true,
    },
    keyboard:{
      enabled:true,
      onlyInViewport:true,
    },
    mousewheel: true,
    // effect : 'fade',
    // slidesperView:10,
    // stopOnLastSlide:true,
    
}) 

// 2
// 这个是定义一个轮播对象var mySwiper = new Swiper (
  var mySwiper2 = new Swiper ('#top1', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    // pagination: {
    //   el: '#top-page1',
    // },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '#top-prev1',
      prevEl: '#top-next1',
    },
    
    // // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },

    autoplay: {
      delay: 5000,
      stopOnLastSlide: false,
      disableOnInteraction: true,
    },
    keyboard:{
      enabled:true,
      onlyInViewport:true,
    },
    mousewheel: true,
    // effect : 'fade',
    // slidesperView:10,
    // stopOnLastSlide:true,
    
}) 
// 3
// 这个是定义一个轮播对象var mySwiper = new Swiper (
  var mySwiper3 = new Swiper ('#top2', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    // pagination: {
    //   el: '#top-page2',
    // },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '#top-prev2',
      prevEl: '#top-next2',
    },
    
    // // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },

    autoplay: {
      delay: 5000,
      stopOnLastSlide: false,
      disableOnInteraction: true,
    },
    keyboard:{
      enabled:true,
      onlyInViewport:true,
    },
    mousewheel: true,
    // effect : 'fade',
    // slidesperView:10,
    // stopOnLastSlide:true,
    
}) 
// 4
// 这个是定义一个轮播对象var mySwiper = new Swiper (
  var mySwiper4 = new Swiper ('#top3', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    // pagination: {
    //   el: '#top-page2',
    // },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '#top-prev3',
      prevEl: '#top-next3',
    },
    
    // // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },

    autoplay: {
      delay: 5000,
      stopOnLastSlide: false,
      disableOnInteraction: true,
    },
    keyboard:{
      enabled:true,
      onlyInViewport:true,
    },
    mousewheel: true,
    // effect : 'fade',
    // slidesperView:10,
    // stopOnLastSlide:true,
    
}) 
// 5
// 这个是定义一个轮播对象var mySwiper = new Swiper (
  var mySwiper5 = new Swiper ('#top4', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    // pagination: {
    //   el: '#top-page4',
    // },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '#top-prev4',
      prevEl: '#top-next4',
    },
    
    // // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },

    autoplay: {
      delay: 5000,
      stopOnLastSlide: false,
      disableOnInteraction: true,
    },
    keyboard:{
      enabled:true,
      onlyInViewport:true,
    },
    mousewheel: true,
    // effect : 'fade',
    // slidesperView:10,
    // stopOnLastSlide:true,
    
})