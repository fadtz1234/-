$smartAD({
    position:'tr',
    link:"https://www.baidu.com",
    content:"在线瞭妹",
style:{
    background:"#le4e7b"//设置颜色
},
    close:true,
    fixed:true,
    before:function(option,win,winHeader,winBody){
         alert(option.link);
    },
    after:function(option,win,winHeader,winBody){
  
       winHeader.css("background","#1e4e7b");
        
    },

});
$("#ad4").smartAD(
    {
    position:'ml',
close:true,
fixed:true,
link:"http:/www.youku.com",
style:{
    height:400,
    width:600,
},
    }
);

//    $("#ad2").smartAD({fixed:true,link:"http://www.baidu.com"});//jqueryObject生成的AD，如果需要浮动固定位置，必须显示的生命fixed:true.
//    $("#ad3").smartAD({position:"mm",link:"http://www.google.com",delay:6000});