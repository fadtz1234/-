$("#talk").hide();
$("#kenr").mouseover(function name(params){
    $("#talk").show();
})
$("#kenr").mouseout(function name(params){
    $("#talk").hide();
})
// 2
$("#talk1").hide();
$("#kenr1").mouseover(function name(params){
    $("#talk1").show();
})
$("#kenr1").mouseout(function name(params){
    $("#talk1").hide();
})
// 3
$("#talk2").hide();
$("#kenr2").mouseover(function name(params){
    $("#talk2").show();
})
$("#kenr2").mouseout(function name(params){
    $("#talk2").hide();
})






var mySwiper = new Swiper ('#swiper-Top', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    // el是表示你在分页器绑定的html标签
    pagination: {
      el: '.swiper-pagination',
      
    },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
      // hideOnClick :true,
    },
    autoplay:{
      delay:3000,
      stopOnLastSlide:false,
      disableOnInteraction:true,
    },
    effect : 'fade',
    // 如果需要滚动条
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },
  })      