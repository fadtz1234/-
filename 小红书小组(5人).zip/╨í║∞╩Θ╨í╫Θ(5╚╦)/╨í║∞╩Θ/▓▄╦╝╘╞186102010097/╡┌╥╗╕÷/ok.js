$("#talk").hide();
$("#kenr").mouseover(function name(params){
    $("#talk").show();
})
$("#kenr").mouseout(function name(params){
    $("#talk").hide();
})
// 2
$("#talk1").hide();
$("#kenr1").mouseover(function name(params){
    $("#talk1").show();
})
$("#kenr1").mouseout(function name(params){
    $("#talk1").hide();
})
// 3
$("#talk2").hide();
$("#kenr2").mouseover(function name(params){
    $("#talk2").show();
})
$("#kenr2").mouseout(function name(params){
    $("#talk2").hide();
})
