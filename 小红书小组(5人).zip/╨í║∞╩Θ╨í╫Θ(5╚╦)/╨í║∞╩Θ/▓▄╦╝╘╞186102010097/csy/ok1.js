$("#person").mouseover(function name(params) {
    $("#name-show").show();
})
// mouseout移出
$("#person").mouseout(function name(params) {
    $("#name-show").hide();
})

$("#person2").mouseover(function name(params) {
    $("#name2-show").show();
})
// mouseout移出
$("#person2").mouseout(function name(params) {
    $("#name2-show").hide();
})