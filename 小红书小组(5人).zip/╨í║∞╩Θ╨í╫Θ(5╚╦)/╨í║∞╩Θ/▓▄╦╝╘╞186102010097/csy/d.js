$("#person").mouseover(function name(params){
    $("#name-show").show();
})
// mouseout移出
$("#person").mouseout(function name(params){
    $("#name-show").hide();
    })