$("#talk").hide();
$("#kenr").mouseover(function name(params){
    $("#talk").show();
})
$("#kenr").mouseout(function name(params){
    $("#talk").hide();
})
// 2
$("#talk1").hide();
$("#kenr1").mouseover(function name(params){
    $("#talk1").show();
})
$("#kenr1").mouseout(function name(params){
    $("#talk1").hide();
})
// 3
$("#talk2").hide();
$("#kenr2").mouseover(function name(params){
    $("#talk2").show();
})
$("#kenr2").mouseout(function name(params){
    $("#talk2").hide();
})


$("#person1").mouseover(function name(params){
    $("#name1-show").show();
})
$("#person1").mouseout(function name(params){
    $("#name1-show").hide();
})
$("#person2").mouseover(function name(params){
    $("#name2-show").show();
})
$("#person2").mouseout(function name(params){
    $("#name2-show").hide();
})
$("#person3").mouseover(function name(params){
    $("#name3-show").show();
})
$("#person3").mouseout(function name(params){
    $("#name3-show").hide();
})
$("#person4").mouseover(function name(params){
    $("#name4-show").show();
})
$("#person4").mouseout(function name(params){
    $("#name4-show").hide();
})
$("#ll").click(
    function (params) {
        $("#ll").addClass("current");
        $("#ll2").removeClass("current");
        $("#ll3").removeClass("current");
        $("#ss").css("background-image","url(./image/shai.JPG)")
    }
)
$("#ll2").click(
    function (params) {
        $("#ll2").addClass("current")
        $("#ll").removeClass("current");
        $("#ll3").removeClass("current");
        $("#ss").css("background-image","url(./image/bj.JPG)")
    }
)
$("#ll3").click(
    function (params) {
        $("#ll3").addClass("current")
        $("#ll2").removeClass("current");
        $("#ll1").removeClass("current");
        $("#ss").css("background-image","url(./image/wh.JPG)")
    }
)


$("#22").click(
    function (params) {
        $("#22").addClass("current");
        $("#33").removeClass("current");
        $("#44").removeClass("current");
        $("#55").removeClass("current");
        $("#nf").css("background-image","url(./image/2016.PNG)")
    }
)
$("#33").click(
    function (params) {
        $("#33").addClass("current")
        $("#22").removeClass("current");
        $("#44").removeClass("current");
        $("#55").removeClass("current");
        $("#nf").css("background-image","url(./image/2017.PNG)")
    }
)
$("#44").click(
    function (params) {
        $("#44").addClass("current")
        $("#22").removeClass("current");
        $("#33").removeClass("current");
        $("#55").removeClass("current");
        $("#nf").css("background-image","url(./image/2018.PNG)")
    }
)

$("#55").click(
    function (params) {
        $("#55").addClass("current");
        $("#33").removeClass("current");
        $("#44").removeClass("current");
        $("#22").removeClass("current");
        $("#nf").css("background-image","url(./image/2019.PNG)")
    }
)