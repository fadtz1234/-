$("#person").mouseover(function name(params) {
    $("#name-show").show();
})
// mouseout移出
$("#person").mouseout(function name(params) {
    $("#name-show").hide();
})


$("#person1").mouseover(function name(params){
    $("#name3-show").show();
})
// mouseout移出
$("#person1").mouseout(function name(params){
    $("#name3-show").hide();
    })