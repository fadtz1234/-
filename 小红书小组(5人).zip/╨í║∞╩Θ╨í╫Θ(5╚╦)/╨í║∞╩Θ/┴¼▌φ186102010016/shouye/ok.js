$("#talk").hide();
$("#kenr").mouseover(function name(params){
    $("#talk").show();
})
$("#kenr").mouseout(function name(params){
    $("#talk").hide();
})
// 2
$("#talk1").hide();
$("#kenr1").mouseover(function name(params){
    $("#talk1").show();
})
$("#kenr1").mouseout(function name(params){
    $("#talk1").hide();
})
// 3
$("#talk2").hide();
$("#kenr2").mouseover(function name(params){
    $("#talk2").show();
})
$("#kenr2").mouseout(function name(params){
    $("#talk2").hide();
})

$("#person").mouseover(function name(params){
    $("#name-show").show();
})
// mouseout移出
$("#person").mouseout(function name(params){
    $("#name-show").hide();
    })

    $("#person1").mouseover(function name(params){
        $("#name1-show").show();
    })
    // mouseout移出
    $("#person1").mouseout(function name(params){
        $("#name1-show").hide();
        })

var mySwiper = new Swiper('.swiper-container', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    autoplay: {
      delay: 2000,
      stopOnLastSlide: false,
      disableOnInteraction: true,
    },
  })

