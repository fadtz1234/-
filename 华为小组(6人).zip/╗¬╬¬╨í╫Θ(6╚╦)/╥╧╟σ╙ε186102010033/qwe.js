// 绑定第一个DIV的点击事件
$("#tab-top").click(function (e) { 
    // 当你点击的div添加选中的class
    // 去除另外两个div的选中class
    $("#tab-top").addClass("选中");
    $("#tab-top2").removeClass("选中");
    $("#tab-top3").removeClass("选中");
    // attr是设置属性,通过设置属性更换图片
    $("#img").attr("src","1.jpg");
});

$("#tab-top2").click(function (e) { 
    e.preventDefault();
    $("#tab-top2").addClass("选中");
    $("#tab-top").removeClass("选中");
    $("#tab-top3").removeClass("选中");
    $("#img").attr("src","2.jpg");
});

$("#tab-top3").click(function (e) { 
    e.preventDefault();
    $("#tab-top3").addClass("选中");
    $("#tab-top2").removeClass("选中");
    $("#tab-top").removeClass("选中");
    $("#img").attr("src","3.jpg");
});



$("#tab-top").mouseover(function () { 
   $("#tab-top").addClass("选中");  
});

$("#tab-top").mouseout(function () { 
    $("#tab-top").removeClass("选中");  
 });

 $("#tab-top2").mouseover(function () { 
    $("#tab-top2").addClass("选中");  
 });
 $("#tab-top2").mouseout(function () { 
    $("#tab-top2").removeClass("选中");  
 });