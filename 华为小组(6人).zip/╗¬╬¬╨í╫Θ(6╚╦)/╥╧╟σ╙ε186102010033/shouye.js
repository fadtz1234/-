// 头顶图片点击关闭
$("#xianshi").show();

$("#dianji").click(
    function name(params)
    {

        $("#xianshi").hide();
    }
)

$("#1").hide();

$("#2").mouseout(function name(params) 
{ 
  $("#1").hide();
});

$("#2").mouseover(function name(params) { 
  
  $("#1").show();
});


var mySwiper = new Swiper ('.swiper-container', {
    // direction: 'vertical', // 垂直切换选项
    loop: true, // 循环模式选项
    
    // 如果需要分页器
    pagination: {
      el: '.swiper-pagination',
    },
    
    // 如果需要前进后退按钮
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },

    autoplay: {
        delay: 5000,
        stopOnLastSlide: false,
        disableOnInteraction: true,
        },
    
    // 如果需要滚动条
    // scrollbar: {
    // //   el: '.swiper-scrollbar',
    // },
  })     
  
  // 移入显示阴影效果
  $(document).ready(function(){  
    $(".e8").mouseover(function(){
        $(".e8").addClass("m1");
    });
    $(".e8").mouseout(function(){
        $(".e8").removeClass("m1");
    });
}); 

// 第二行 第四行
$(document).ready(function(){  
  $(".e25").mouseover(function(){
      $(".e25").addClass("m1");
  });
  $(".e25").mouseout(function(){
      $(".e25").removeClass("m1");
  });
}); 

//   第三行 
$(document).ready(function(){  
  $(".e26").mouseover(function(){
      $(".e26").addClass("m1");
  });
  $(".e26").mouseout(function(){
      $(".e26").removeClass("m1");
  });
}); 

//第四行
$(document).ready(function(){  
  $(".e27").mouseover(function(){
      $(".e27").addClass("m1");
  });
  $(".e27").mouseout(function(){
      $(".e27").removeClass("m1");
  });
}); 

